// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xdut_func.h"

extern XDut_func_Config XDut_func_ConfigTable[];

XDut_func_Config *XDut_func_LookupConfig(u16 DeviceId) {
	XDut_func_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XDUT_FUNC_NUM_INSTANCES; Index++) {
		if (XDut_func_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XDut_func_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDut_func_Initialize(XDut_func *InstancePtr, u16 DeviceId) {
	XDut_func_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDut_func_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDut_func_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

